package com.example.itjobtracker.service;

import com.example.itjobtracker.model.JobPosting;
import com.example.itjobtracker.repository.JobPostingRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class JobPostingService {
    private final JobPostingRepository repository;

    public JobPostingService(JobPostingRepository repository) {
        this.repository = repository;
    }

    public List<JobPosting> search(String companyName, String jobTitle, BigDecimal minSalary, BigDecimal maxSalary) {
        return repository.search(emptyToNull(companyName), emptyToNull(jobTitle), minSalary, maxSalary);
    }

    public JobPosting save(JobPosting jobPosting) {
        return repository.save(jobPosting);
    }

    public Optional<JobPosting> findById(Long id) {
        return repository.findById(id);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    private String emptyToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }
}