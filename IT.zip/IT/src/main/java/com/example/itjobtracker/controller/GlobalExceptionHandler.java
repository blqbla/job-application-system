package com.example.itjobtracker.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public String handleAnyException(Exception ex, Model model) {
        model.addAttribute("studentName", "王朝东");
        model.addAttribute("errorMessage", "系统发生错误：" + ex.getMessage());
        return "error";
    }
}