package com.example.itjobtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItJobTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ItJobTrackerApplication.class, args);
    }
}