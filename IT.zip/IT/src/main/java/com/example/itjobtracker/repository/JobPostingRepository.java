package com.example.itjobtracker.repository;

import com.example.itjobtracker.model.JobPosting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface JobPostingRepository extends JpaRepository<JobPosting, Long> {

    @Query("SELECT j FROM JobPosting j " +
           "WHERE (:companyName IS NULL OR j.companyName LIKE %:companyName%) " +
           "AND (:jobTitle IS NULL OR j.jobTitle LIKE %:jobTitle%) " +
           "AND (:minSalary IS NULL OR j.salary >= :minSalary) " +
           "AND (:maxSalary IS NULL OR j.salary <= :maxSalary)")
    List<JobPosting> search(
            @Param("companyName") String companyName,
            @Param("jobTitle") String jobTitle,
            @Param("minSalary") BigDecimal minSalary,
            @Param("maxSalary") BigDecimal maxSalary
    );
}