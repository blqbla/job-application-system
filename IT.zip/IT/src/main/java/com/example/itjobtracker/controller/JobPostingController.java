package com.example.itjobtracker.controller;

import com.example.itjobtracker.model.JobPosting;
import com.example.itjobtracker.service.JobPostingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class JobPostingController {

    private final JobPostingService service;

    public JobPostingController(JobPostingService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String index(@RequestParam(required = false) String companyName,
                        @RequestParam(required = false) String jobTitle,
                        @RequestParam(required = false) BigDecimal minSalary,
                        @RequestParam(required = false) BigDecimal maxSalary,
                        Model model) {
        List<JobPosting> jobs = service.search(companyName, jobTitle, minSalary, maxSalary);
        model.addAttribute("jobs", jobs);
        model.addAttribute("companyName", companyName);
        model.addAttribute("jobTitle", jobTitle);
        model.addAttribute("minSalary", minSalary);
        model.addAttribute("maxSalary", maxSalary);
        model.addAttribute("studentName", "王朝东");
        return "index";
    }

    @GetMapping("/jobs/new")
    public String newJob(Model model) {
        model.addAttribute("job", new JobPosting());
        model.addAttribute("studentName", "王朝东");
        return "add";
    }

    @PostMapping("/jobs")
    public String create(@ModelAttribute JobPosting job) {
        service.save(job);
        return "redirect:/";
    }

    @GetMapping("/jobs/{id}/edit")
    public String edit(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        return service.findById(id)
                .map(job -> {
                    model.addAttribute("job", job);
                    model.addAttribute("studentName", "王朝东");
                    return "edit";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("errorMessage", "未找到岗位ID: " + id);
                    return "redirect:/";
                });
    }

    @PostMapping("/jobs/{id}")
    public String update(@PathVariable Long id, @ModelAttribute JobPosting job) {
        job.setId(id);
        service.save(job);
        return "redirect:/";
    }

    @PostMapping("/jobs/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            service.deleteById(id);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "删除失败，可能岗位不存在: " + id);
        }
        return "redirect:/";
    }
}